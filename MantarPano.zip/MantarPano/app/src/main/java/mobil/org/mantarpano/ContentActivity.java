package mobil.org.mantarpano;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

/**
 * Created by yasü on 29.11.2017.
 */

public class ContentActivity extends AppCompatActivity
{
    Button btnGeri;
    Intent intent;
    RelativeLayout rl;
    EditText edt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);
        rl = (RelativeLayout) findViewById(R.id.relativeLayout);
        btnGeri = (Button) findViewById(R.id.buttonGeri);
        edt= (EditText) findViewById(R.id.editText);

//               btnGeri.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                intent = new Intent(ContentActivity.this, MainActivity.class);
//                ContentActivity.this.startActivity(intent);
//                ContentActivity.this.finish();
//            }
//        });
    }
    public void Tiklandi(View v){
        if(v.getId()==R.id.buttonGeri){
            intent = new Intent(ContentActivity.this, MainActivity.class);
            ContentActivity.this.startActivity(intent);
            ContentActivity.this.finish();
        }
        else if(v.getId()==R.id.buttonKaydet){
            CharSequence charSequence=edt.getText();
            intent=new Intent(ContentActivity.this, MainActivity.class);
            intent.putExtra("anahtar",charSequence);
            startActivity(intent);
            ContentActivity.this.finish();
        }
    }
}
